import React from 'react'

const ContentBox = () => {
  return (
    <div>ContentBox</div>
  )
}

export default ContentBox